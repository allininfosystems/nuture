var config = {
    map: {
        '*': {
            jscolor: 'Plumrocket_Base/js/jscolor'
        }
    }
};